# Câu 1 - Đề 2
def TongUocSo(n):
    tong = 0
    for i in range(1, n + 1):
        if n % i == 0:
            tong += i
    return tong

def S(n):
    s = 0
    for i in range(1, n + 1):
        s += (i ** i)
    return s

n = int(input("Nhập giá trị 1<=n<=99: "))
while n < 1 or n > 99:
    n = int(input("Nhập lại giá trị 1<=n<=99: "))

print("Tổng các ước số là:", TongUocSo(n))
print("S =", S(n))
